#!/usr/bin/env python3

import sys
sys.path.append("/home/hecate/projects/hexlet/python-project-49/brain_games")
from cli import welcome_user


def main():
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    main()


welcome_user()
